from beem_sms.sms_sender import SMSSender
import responses

@responses.activate
def test_send_sms_success():
    responses.add(responses.POST, "https://apisms.beem.africa/v1/send", status=200)
    API_key = "38e0721c4b4b6095"
    secret_key = "ODUzYmJiYmEzMjEzZTc3NGYxOGM2YjE2ZDJjOGVkNGEzMDI0MWQwN2Q4MjljNGQyNGJiNTUzOTM0NWEzZDliMg=="
    sms_sender = SMSSender(api_key= API_key, secret_key=secret_key, base_url="https://apisms.beem.africa")
    message = sms_sender.send_sms(dest_addr="255742892731", message="Hi, James")
    # assert success is True
    assert message == "SMS sent successfully"


# API_key = "38e0721c4b4b6095"
# secret_key = "ODUzYmJiYmEzMjEzZTc3NGYxOGM2YjE2ZDJjOGVkNGEzMDI0MWQwN2Q4MjljNGQyNGJiNTUzOTM0NWEzZDliMg=="


# # tests/test_sms_sender.py
# from sms_package.sms_sender import SMSSender
# import responses

# @responses.activate
# def test_send_sms_success():
#     responses.add(responses.POST, "https://apisms.beem.africa/v1/send", status=200)
#     sms_sender = SMSSender(api_key="fake_key", secret_key="fake_secret", base_url="https://apisms.beem.africa")
#     success, message = sms_sender.send_sms(dest_addr="255655060606", message="Test Message")
#     assert success is True
#     assert message == "SMS sent successfully!"

# @responses.activate
# def test_send_sms_failure():
#     responses.add(responses.POST, "https://apisms.beem.africa/v1/send", status=500, body="Internal Server Error")
#     sms_sender = SMSSender(api_key="fake_key", secret_key="fake_secret", base_url="https://apisms.beem.africa")
#     success, message = sms_sender.send_sms(dest_addr="255655060606", message="Test Message")
#     assert success is False
#     assert "SMS sending failed. Status code: 500, Response: Internal Server Error" in message
