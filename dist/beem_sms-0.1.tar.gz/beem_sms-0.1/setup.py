from setuptools import setup, find_packages

setup(
name="beem_sms",
version="0.1",
packages=find_packages(),
install_requires=['requests', 'responses']
    
)